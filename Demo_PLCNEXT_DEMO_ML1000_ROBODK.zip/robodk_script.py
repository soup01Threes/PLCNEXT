from robodk import robolink    # RoboDK API
from robodk import robomath    # Robot toolbox
import datetime
import time
from opcua import Client,ua
import random
import os
import paramiko

SFTP_FROM='C:\FTPFiles\RoboDK'
SFTP_TO='/home/root/coral/pycoral/test_data/'

config = {
	"host" : "192.168.3.10",
	"port" : 22,
	"username" : "SFTPUSER",
	"password"   : "SFTPPASSWORD"
}
SFTPClient=paramiko.SSHClient()
SFTPClient.set_missing_host_key_policy(paramiko.AutoAddPolicy)


os.chdir(r'C:\Users\root\Desktop\ML1000_package\ML1000_package')

RDK = robolink.Robolink()


UR=RDK.Item("UR5")
CameraPosition1=RDK.Item('tCamera1')
CameraPosition2=RDK.Item('tCamera2')
CameraPosition3=RDK.Item('tCamera3')
CameraPosition4=RDK.Item('tCamera4')
CameraPosition5=RDK.Item('tCamera5')
CameraPosition6=RDK.Item('tCamera6')
Prog=RDK.Item('pMain')
ENDPOINT='opc.tcp://user:passwd@192.168.3.10:4840'
USERNAME='PLCNEXTUSERNAME'
PASSWORD='PLCNEXTPASSWORD'


NODE_BUSY='ns=5;s=Arp.Plc.Eclr/Main1.ReadFromRoboDK.bBusy'
NODE_END='ns=5;s=Arp.Plc.Eclr/Main1.ReadFromRoboDK.bEnd'
NODE_IMAGEISSAVED='ns=5;s=Arp.Plc.Eclr/Main1.ReadFromRoboDK.bImageisSaved'
NODE_SIMAGEPATH='ns=5;s=Arp.Plc.Eclr/Main1.ReadFromRoboDK.sImagePath'
NODE_STARTPROGRAM='ns=5;s=Arp.Plc.Eclr/Main1.Write2RoboDK.bStartProgram'
NODE_CANEND='ns=5;s=Arp.Plc.Eclr/Main1.Write2RoboDK.bCanEnd'

client=Client(ENDPOINT)
client.set_user(USERNAME)
client.set_password(PASSWORD)
client.set_security_string('Basic256,Sign,cert.der,key.pem')

try:
    client.connect()
    client.load_type_definitions()
    print('Node2Server is loaded..')
    NodeBusy=client.get_node(NODE_BUSY)
    NodeEnd=client.get_node(NODE_END)
    NodeImageIsSaved=client.get_node(NODE_IMAGEISSAVED)
    NodeSImagePath=client.get_node(NODE_SIMAGEPATH)
    NodeCanEnd=client.get_node(NODE_CANEND)

    print('NodeFromServer is loaded..')
    NodeStartProgram=client.get_node(NODE_STARTPROGRAM)

    Busy=NodeBusy.get_value()
    End=NodeEnd.get_value()
    print(Busy,End)
    
except Exception as e:
    print(e)
    quit()


def WriteNode():
    NodeBusy=client.get_node(NODE_BUSY)
    NodeEnd=client.get_node(NODE_END)
    NodeImageIsSaved=client.get_node(NODE_IMAGEISSAVED)
    NodeSImagePath=client.get_node(NODE_SIMAGEPATH)
    return NodeBusy.get_value(),NodeEnd.get_value(),NodeImageIsSaved.get_value(),NodeSImagePath.get_value()

def ReadNode():
    NodeStart=client.get_node(NODE_STARTPROGRAM)
    NodeCanEnd=client.get_node(NODE_CANEND)  
    return NodeStart.get_value(),NodeCanEnd.get_value()
    
cam_item = RDK.Item("Camera1")
if not cam_item.Valid():
    print('No camera..')
    quit()

           
def createImagePath(s):
    path=getCurrentTime()
    return "C:\FTPFiles\RoboDK"+path+".jpg",path
    

def getCurrentTime():
    return time.strftime('%Y_%m_%d_%H_%M_%S_'+str(random.randint(0,99)))


def Sanp(Path,Cam):
    return RDK.Cam2D_Snapshot(Path,Cam)


def SetNodeValue(Node,value):
    DataType=Node.get_data_type_as_variant_type()
    DataValue=ua.DataValue(ua.Variant(value,DataType))
    Node.set_data_value(DataValue)

NodeSImagePath=client.get_node(NODE_SIMAGEPATH)
flag=[False,False,False,False,False,False]
photoTaken=[False,False,False,False,False,False]
counts=0
start=0
End=False
_busy=False
try :
    while True:
        Busy,End,ImageIsSaved,Path=WriteNode()
        bStartProgram,bCanEnd=ReadNode()
        Pose=UR.Pose()
        if not _busy and bStartProgram :
            _busy=True
            PathArray=[]
            value = Prog.RunProgram()
            End=False
        if Prog.Busy():
            NodeBusy.set_value(ua.DataValue(True))
            if Pose == CameraPosition1.Pose() and not flag[0]:
                path,p=createImagePath("001")
                ret=Sanp(path,cam_item)
                print('Camera pos1..')
                if ret:
                    flag[0]=True
                    PathArray.append(p)
                    UR.setDO('CamIO_1',1)

            elif Pose == CameraPosition2.Pose()and not flag[1]:
                path,p=createImagePath("002")
                ret=Sanp(path,cam_item)
                print('Camera pos2..')
                if ret:
                    UR.setDO('CamIO_2',1)
                    PathArray.append(p)
                    flag[1]=True

            elif Pose == CameraPosition3.Pose()and not flag[2]:
                path,p=createImagePath("003")
                ret=Sanp(path,cam_item)
                print('Camera pos3..')
                if ret:
                    UR.setDO('CamIO_3',1)
                    PathArray.append(p)
                    flag[2]=True

            elif Pose == CameraPosition4.Pose()and not flag[3]:
                path,p=createImagePath("004")
                ret=Sanp(path,cam_item)
                print('Camera pos4..')
                if ret:
                    UR.setDO('CamIO_4',1)
                    PathArray.append(p)
                    flag[3]=True

            elif Pose == CameraPosition5.Pose()and not flag[4]:
                path,p=createImagePath("005")
                ret=Sanp(path,cam_item)
                print('Camera pos5..')
                if ret:
                    UR.setDO('CamIO_5',1)
                    PathArray.append(p)
                    flag[4]=True

            elif Pose == CameraPosition6.Pose()and not flag[5]:
                path,p=createImagePath("006")
                ret=Sanp(path,cam_item)
                print('Camera pos6..')
                if ret:
                    UR.setDO('CamIO_6',1)
                    PathArray.append(p)
                    flag[5]=True

            if flag[0] and flag[1] and flag[2] and flag[3] and flag[4] and flag[5]:
                SFTPClient.connect(config['host'], port = config['port'],username = config['username'],password = config['password'])
                sftp_con = SFTPClient.open_sftp()
                for i in range(0,6):
                    sftp_con.put("C:\FTPFiles\RoboDK"+PathArray[i]+".jpg", "/home/root/coral/pycoral/test_data/"+PathArray[i]+".jpg")
                SFTPClient.close()
                SetNodeValue(NodeSImagePath,PathArray)
                NodeEnd.set_value(ua.DataValue(True))
                End=True
                start=time.time()
        else:
            NodeBusy.set_value(ua.DataValue(False))
            PathArray=[]
            for i in range(0,6):
                flag[i]=False
                         
        if End:
            print('NodeEnd=True..')
            NodeEnd.set_value(ua.DataValue(True))
            if time.time()-start > 2 and False :
                print('NodeEnd=False..')
                NodeEnd.set_value(ua.DataValue(False))
                
        if bCanEnd:
            print('NodeEnd=False--Cam End..')
            NodeEnd.set_value(ua.DataValue(False))
            _busy=False
            
except Exception as e:
    print(e)
    client.disconnect()

 
