#mporting necessary modules

import grpc
from google.protobuf.empty_pb2 import Empty
from PROTO.Authentication_pb2 import CreateSessionRequest
from PROTO.Authentication_pb2_grpc import AuthenticationStub
from PROTO.IDataAccessService_pb2 import IDataAccessServiceReadSingleRequest, \
    IDataAccessServiceReadRequest, IDataAccessServiceWriteSingleRequest, IDataAccessServiceWriteRequest
from PROTO.IDataAccessService_pb2_grpc import IDataAccessServiceStub
from PROTO.PLCnextBase_pb2 import CoreType
from PROTO.ErrorCode_pb2 import ErrorCode

#Opening a gRPC channel
channel=grpc.insecure_channel("unix:/run/plcnext/grpc.sock")

import argparse
import time

import numpy as np
from PIL import Image
from pycoral.adapters import classify
from pycoral.adapters import common
from pycoral.utils.dataset import read_label_file
from pycoral.utils.edgetpu import make_interpreter


def WriteSingle_StringValue(P_PortName,P_StringValue):
    stub=IDataAccessServiceStub(channel)
    response1= IDataAccessServiceWriteSingleRequest()
    response1.data.PortName= P_PortName
    response1.data.Value.TypeCode=19
    response1.data.Value.StringValue=P_StringValue
    response=stub.WriteSingle(response1)
    return response

def WriteSingle_BoolValue(P_PortName,value):
    stub=IDataAccessServiceStub(channel)
    response1= IDataAccessServiceWriteSingleRequest()
    response1.data.PortName= P_PortName
    response1.data.Value.TypeCode=2
    response1.data.Value.BoolValue=value
    response=stub.WriteSingle(response1)
    return response    

def read_single_value(stub, port_name):

    single_read_request = IDataAccessServiceReadSingleRequest()
    single_read_request.portName=port_name

    return stub.ReadSingle(single_read_request)


def read_multiple_values(stub, port_names):

    read_request = IDataAccessServiceReadRequest()
    read_request.portNames.extend(port_names)

    return stub.Read(read_request)

def write_single_Stringarray(stub, port_name, value,index):
    
    single_write_request = IDataAccessServiceWriteSingleRequest()
    single_write_request.data.PortName = port_name+'['+str(index)+']'
    single_write_request.data.Value.TypeCode = 19
    single_write_request.data.Value.StringValue=value
    return stub.WriteSingle(single_write_request)

def write_single_Realarray(stub, port_name, value,index):
    
    single_write_request = IDataAccessServiceWriteSingleRequest()
    single_write_request.data.PortName = port_name+'['+str(index)+']'
    single_write_request.data.Value.TypeCode = 13
    single_write_request.data.Value.FloatValue=value
    return stub.WriteSingle(single_write_request)


  

#TPU Path setup
LABELPATH='/home/root/coral/pycoral/test_data/imagenet_labels_2.txt'
MODELPATH='/home/root/coral/pycoral/test_data/mobilenet_v1_0.75_192_quant_edgetpu.tflite'
top_k=2
threshold=0.0
count=2
input_mean=128
input_std=128

DEBUG=False

PORTS=['Arp.Plc.Eclr/Main1.ReadFromRoboDK.sImagePath']

WORKING_DIR='/home/root/coral/pycoral/test_data/'

def main():

  labels = read_label_file(LABELPATH) if LABELPATH else {}

  interpreter = make_interpreter(*MODELPATH.split('@'))
  interpreter.allocate_tensors()

  # Model must be uint8 quantized
  if common.input_details(interpreter, 'dtype') != np.uint8:
    raise ValueError('Only support uint8 input type.')

  size = common.input_size(interpreter)

  params = common.input_details(interpreter, 'quantization_parameters')
  scale = params['scales']
  zero_point = params['zero_points']
  mean = input_mean
  std = input_std

  bInit=False
  bBusy=False

  stub=IDataAccessServiceStub(channel)
  step=0
  #-------------------------------------------------------------
  
  while True:

    
    PathArray=[]
    bStart2Classification = read_single_value(stub, 'Arp.Plc.Eclr/Main1.Write2ML1000.bStart2Classification')._ReturnValue.Value.BoolValue
    bPaths=read_multiple_values(stub, PORTS)

    if bStart2Classification and step ==0 :
      print('command is received.')
      bBusy=True
      WriteSingle_BoolValue("Arp.Plc.Eclr/Main1.ReadFromML1000.bBusy", True)
      if not bInit:
 
        bInit=True
        Paths=bPaths._ReturnValue[0].Value.ArrayValue
        for path in Paths.ArrayElements:
          PathArray.append(path.StringValue)
          print(path.StringValue)
        step=10
      # Run inference
    if step==10:
      i=0
      for path in PathArray:
        
        image = Image.open(WORKING_DIR+path+".jpg").convert('RGB').resize(size, Image.ANTIALIAS)
        if abs(scale * std - 1) < 1e-5 and abs(mean - zero_point) < 1e-5:
          # Input data does not require preprocessing.
          common.set_input(interpreter, image)
        else:
          # Input data requires preprocessing
          normalized_input = (np.asarray(image) - mean) / (std * scale) + zero_point
          np.clip(normalized_input, 0, 255, out=normalized_input)
          common.set_input(interpreter, normalized_input.astype(np.uint8)) 

        print('----INFERENCE TIME----')
        print('Note: The first inference on Edge TPU is slow because it includes',
              'loading the model into Edge TPU memory.')
        for _ in range(count):
          start = time.perf_counter()
          interpreter.invoke()
          inference_time = time.perf_counter() - start
          classes = classify.get_classes(interpreter, top_k, threshold)
          print('%.1fms' % (inference_time * 1000))

        print('-------RESULTS--------')
        write=False
        for c in classes:
          print('%s: %.5f' % (labels.get(c.id, c.id), c.score))
          if write is False:
            result=labels.get(c.id, c.id)
            score=c.score
            write=True

        write_single_Stringarray(stub,'Arp.Plc.Eclr/Main1.ReadFromML1000.Result_label',result,i)
        write_single_Realarray(stub,'Arp.Plc.Eclr/Main1.ReadFromML1000.Result_Score',score,i)
        print(i)
        i=i+1

        result=('%s' % (labels.get(c.id, c.id)))
        WriteSingle_StringValue("Arp.Plc.Eclr/Main1.INT_A", result)
        step=20
    if step ==20:
        bBusy=False    
        WriteSingle_BoolValue("Arp.Plc.Eclr/Main1.ReadFromML1000.bBusy", False)
        WriteSingle_BoolValue("Arp.Plc.Eclr/Main1.ReadFromML1000.bFinished", True)

    if not bStart2Classification and step==20:
      WriteSingle_BoolValue("Arp.Plc.Eclr/Main1.ReadFromML1000.bFinished", False)
      step=0
      bInit=False


if __name__ == '__main__':
  main()
